Product: Magazine Box, September 2014
Designer: Scott Austin, scotta@obrary.com
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Magazine Box is designed to be cut from 1/4" plywood on a Laser Cutter.